const mongoose = require("mongoose");

const episodeSchema = new mongoose.Schema({
    title: String,
    content: String,
    createdAt: { type: Date, default: Date.now }
});

const novelSchema = new mongoose.Schema({
    title: { type: String, required: true },
    mainCate: String,
    secondCate: String,
    quote: String,
    shorts: String,
    rating: { type: String, enum: ["general", "rated"], default: "general" },
    tags: [String],
    episodes: [episodeSchema],
    coverUrl: String,
    status: { type: String, enum: ["draft", "published"], default: "draft" },
    createdAt: { type: Date, default: Date.now }
});

module.exports = mongoose.model("Novel", novelSchema);
