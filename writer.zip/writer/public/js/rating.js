document.addEventListener("change", (e) => {
    if (e.target && e.target.id === "rating") {
        const checkboxArea = document.getElementById("rated_choice");
        if (e.target.value === "rated") {
            checkboxArea.innerHTML = `
            <div class="m-3 mb-0">
                <form class="d-flex flex-column mb-0">
                    <input type="checkbox" id="vehicle1" name="vehicle1" value="Bike">
                    <label for="vehicle1">มีการบรรยายกิจกรรมทางเพศ</label><br>
                    <input type="checkbox" id="vehicle2" name="vehicle2" value="Car">
                    <label for="vehicle2">มีการบรรยายเนื้อหาที่เกี่ยวกับการใช้ความรุนแรงสูง</label><br>
                    <input type="checkbox" id="vehicle3" name="vehicle3" value="Boat">
                    <label for="vehicle3">มีเนื้อหาที่เครียดหรือหดหู่มาก  อาจกระทบต่อภาวะทางจิตใจ</label><br><br>
                </form>
            </div>
      `;
        } else {
            checkboxArea.innerHTML = "";
        }
    }
});

