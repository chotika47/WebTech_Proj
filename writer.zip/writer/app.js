const express = require("express");
const path = require("path");
//DB
const mongoose = require('mongoose');
const Novel = require("./models/novel"); // import model
const multer = require("multer");//for image uploading
const app = express();
const port = 4000;

// ตั้งค่า view engine เป็น ejs
app.set("view engine", "ejs");
app.set("views", path.join(__dirname, "views"));

// Middleware ใช้ static files
app.use(express.json());//รองรับไฟล์JSONเพื่อดึงข้อมูล
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, "public")));

//เชื่อมMongoDB
mongoose.connect('mongodb://localhost:27017/Writer', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log("MongoDB connected"))
    .catch(err => console.log(err));


// เก็บไฟล์รูปลงโฟลเดอร์ public/uploads
const storage = multer.diskStorage({
    destination: function (req, file, cb) {
        cb(null, "public/uploads");
    },
    filename: function (req, file, cb) {
        const uniqueSuffix = Date.now() + "-" + Math.round(Math.random() * 1e9);
        const ext = file.originalname.split(".").pop();
        cb(null, file.fieldname + "-" + uniqueSuffix + "." + ext);
    }
});

const upload = multer({ storage: storage });
//----------------- routes --------------------------
//หน้ายอดขาย
app.get("/sell", (req, res) => {
    res.render("sell", { title: "ยอดขาย" });
});

//หน้าหลักนักเขียนนิยาย
app.get("/", async (req, res) => {
    try {
        // ดึงนิยายทั้งหมด
        const allNovels = await Novel.find().sort({ createdAt: -1 });
        res.render("writtenNovels", {
            title: "งานเขียนทั้งหมด",
            drafts: allNovels.filter(n => n.status === "draft"),
            published: allNovels.filter(n => n.status === "published"),
        });

    } catch (err) {
        console.error(err);
        res.render("writtenNovels", { title: "งานเขียนของคุณ", drafts: [], published: [] });
    }
});


//สร้างนิยายใหม่
app.get("/works/new", (req, res) => {
    res.render("add", { novel: null, totalEp: 0, title: "สร้างนิยายใหม่" });
});
//แก้ไขนิยายที่มีอยู่
app.get("/works/:id", async (req, res) => {
    try {
        const novel = await Novel.findById(req.params.id);
        const totalEp = novel ? novel.episodes.length : 0;
        res.render("add", { novel, totalEp, title: "แก้ไขนิยาย" });
    } catch (err) {
        console.error(err);
        res.redirect("/");
    }
});

// ดึงข้อมูลนิยายตาม ID
app.get("/api/novel/:id", async (req, res) => {
    try {
        const novel = await Novel.findById(req.params.id);
        if (!novel) return res.json({ success: false });
        res.json({ success: true, novel });
    } catch (err) {
        console.error(err);
        res.json({ success: false });
    }
});


// API เพิ่มตอนใหม่
// เพิ่มตอนใหม่
app.post("/works/:id/episodes", async (req, res) => {
    try {
        const novel = await Novel.findById(req.params.id);
        if (!novel) return res.status(404).json({ success: false });

        const { title, content } = req.body;
        const newEp = { title, content };
        novel.episodes.push(newEp);
        await novel.save();

        const lastEp = novel.episodes[novel.episodes.length - 1];

        res.json({
            success: true,
            totalEp: novel.episodes.length,
            episode: lastEp // ส่ง episode ที่สร้างใหม่กลับไปด้วย
        });
    } catch (err) {
        console.error(err);
        res.json({ success: false });
    }
});
// API ลบตอน
app.delete("/works/:id/episodes/:epId", async (req, res) => {
    try {
        const novel = await Novel.findById(req.params.id);
        if (!novel) return res.status(404).json({ success: false });

        const epId = req.params.epId;
        const ep = novel.episodes.id(epId);
        if (!ep) return res.status(404).json({ success: false, message: "Episode not found" });

        ep.deleteOne();
        await novel.save();

        res.json({ success: true, totalEp: novel.episodes.length });
    } catch (err) {
        console.error(err);
        res.json({ success: false });
    }
});
// แก้ไข&บันทึกนิยาย
app.post("/novel/save", async (req, res) => {
    try {
        const { novelId, title, mainCate, secondCate, rating, quote, shorts, tags, coverUrl } = req.body;

        let novel;
        //ถ้าเป็นนิยายที่มีอยู่แล้วให้อัปเดตค่า
        if (novelId) {
            novel = await Novel.findById(novelId);
            if (!novel) return res.json({ success: false });
            novel.title = title;
            novel.mainCate = mainCate;
            novel.secondCate = secondCate;
            novel.rating = rating;
            novel.quote = quote;
            novel.shorts = shorts;
            novel.tags = tags;
            novel.coverUrl = coverUrl;
        } else {
            novel = new Novel({ title, mainCate, secondCate, rating, quote, shorts, tags, coverUrl });
        }

        await novel.save();
        res.json({ success: true, novelId: novel._id });

    } catch (err) {
        console.error(err);
        res.json({ success: false });
    }
});


// อัปโหลดรูปโปรไฟล์
app.post("/upload/profile", upload.single("profile"), (req, res) => {
    if (!req.file) return res.status(400).json({ success: false });
    res.json({ success: true, url: "/uploads/" + req.file.filename });
});

// อัปโหลดปกนิยาย
app.post("/upload/cover", upload.single("cover"), (req, res) => {
    if (!req.file) return res.status(400).json({ success: false });
    res.json({ success: true, url: "/uploads/" + req.file.filename });
});



// run server
app.listen(port, () => {
    console.log(`Server running at http://localhost:${port}`);
});